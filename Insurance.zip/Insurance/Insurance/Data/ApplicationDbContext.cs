﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { 

        } 

        public DbSet<Pojistenec> Pojistenci => Set<Pojistenec>(); 

        public DbSet<Pojistka> Pojistky => Set<Pojistka>(); 

        public DbSet<Udalost> Udalosti => Set<Udalost>();

        public DbSet<Person> Persons => Set<Person>();
        public DbSet<PojistkaPerson> PojistkaPersons => Set<PojistkaPerson>();

        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // unikátní index na Rodné číslo
            modelBuilder.Entity<Pojistenec>()
      .HasIndex(p => p.RodneCislo)
      .IsUnique();

            // 1. Pojistenec → Pojistka : Cascade
            modelBuilder.Entity<Pojistka>()
                .HasOne(p => p.Pojistenec)
                .WithMany(po => po.Pojistky)
                .HasForeignKey(p => p.PojistenecId)
                .OnDelete(DeleteBehavior.Cascade);

            // 2. Pojistka → Udalost : Cascade
            modelBuilder.Entity<Udalost>()
                .HasOne(u => u.Pojistka)
                .WithMany(p => p.Udalosti)
                .HasForeignKey(u => u.PojistkaId)
                .OnDelete(DeleteBehavior.Cascade);

            // 3. Join tabulka PojistkaPerson  (!!!)
            modelBuilder.Entity<PojistkaPerson>()
                .HasKey(pp => new { pp.PojistkaId, pp.PersonId });

            // 3a. Pojistka → PojistkaPerson : **Restrict**  (zabrání dvojité kaskádě)
            modelBuilder.Entity<PojistkaPerson>()
                .HasOne(pp => pp.Pojistka)
                .WithMany(p => p.PojistkaPersons)
                .HasForeignKey(pp => pp.PojistkaId)
                .OnDelete(DeleteBehavior.Restrict);

            // 3b. Person → PojistkaPerson : Cascade  (při smazání osoby jen smažeme vazby)
            modelBuilder.Entity<PojistkaPerson>()
                .HasOne(pp => pp.Person)
                .WithMany(p => p.PojistkaPersons)
                .HasForeignKey(pp => pp.PersonId)
                .OnDelete(DeleteBehavior.Cascade);

            // 4. Volitelně sjednotíme název tabulky Person
            modelBuilder.Entity<Person>().ToTable("Persons");
        }

    }


}
