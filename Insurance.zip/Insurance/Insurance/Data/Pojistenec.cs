﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Insurance.Validators;
using System.Text.RegularExpressions;

namespace Insurance.Data;

public record Pojistenec
{
    [Key]
    public int Id { get; set; }

    



    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Jméno")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Jméno je ve špatném formátu.")]
        public string Jmeno { get; set   ; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Příjmení")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Příjmení je ve špatném formátu.")]
        public string Prijmeni { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Email")]
    [RegularExpression(@".+@.+\..+", ErrorMessage = "Email je ve špatném formátu.")]
    public string Email { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Telefon")]
    [RegularExpression(@"^(\+420\s?)?([5-7]{1}[0-9]{2}(\s?[0-9]{3}){2})$", ErrorMessage = "Telefonní číslo musí být ve formátu +420 123 456 789 nebo 123456789.")]
    public string Telefon { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Město")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Město je ve špatném formátu.")]
        public string Mesto { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Ulice")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*\s?\d{0,5}[a-zA-Z]?$", ErrorMessage = "Ulice je ve špatném formátu.")]

    public string Ulice { get; set; } 

    
    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(11), Display(Name = "Rodné číslo")]
    [RegularExpression(@"^\d{6}/?\d{3,4}$", ErrorMessage = "Zadejte platné rodné číslo ve formátu RRMMDD/XXXX nebo RRMMDDXXXX.")]
    [UniqueRodneCislo]
    [RodneCisloFormat(ErrorMessage = "Rodné číslo má nesprávný formát nebo datum.")]
    public string RodneCislo { get; set; }




    public ICollection<Pojistka> Pojistky { get; set; }


}


