﻿using System.ComponentModel.DataAnnotations;

namespace Insurance.Data;

public class Pojistka
{

    [Key]

    public int Id { get; set; }



    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Druh pojistky")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Je ve špatném formátu.")]
    public string DruhPojistky { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [MaxLength(20), Display(Name = "Předmět pojištění")]
    [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Je ve špatném formátu.")]
    public string PredmetPojisteni { get; set; }

    [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
    [Display(Name = "Výše pojistky")]
    // U typu int je zaručeno, že vstup bude celé číslo.
    // RegularExpression pro int není potřeba a je dokonce chybný (regex pro textové řetězce).
    // MaxLength pro int také není relevantní pro délku řetězce.
    [Range(0, int.MaxValue, ErrorMessage = "Zadejte platné celé číslo.")] // Volitelné: Omezení rozsahu a vlastní zpráva
    public int VysePojistky { get; set; }


    [Display(Name = "Pojištěnec")]
    public int PojistenecId { get; set; } // Cizí klíč pro Pojistenec  

    //public int PersonId { get; set; }

    [Display(Name = "Pojištěná osoba")]
    public Person Person{ get; set; }

    public Pojistenec Pojistenec { get; set; } // Navigační vlastnost pro Pojistenec 

    public ICollection<Udalost> Udalosti { get; set; } 
    public ICollection<PojistkaPerson> PojistkaPersons { get; set; } 

}