﻿using System.ComponentModel.DataAnnotations; 
using System.Collections.Generic;
using Insurance.Validators;
using System.Text.RegularExpressions;

namespace Insurance.Data
{
    public class Person
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Jméno je povinné.")]
        [MaxLength(30), Display(Name = "Jméno")]
        [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Jméno je ve špatném formátu.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Příjmení je povinné.")]
        [MaxLength(30), Display(Name = "Příjmení")]
        [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Příjmení je ve špatném formátu.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Rodné číslo je povinné.")]
        [MaxLength(11), Display(Name = "Rodné číslo")]
        [RegularExpression(@"^\d{6}/?\d{3,4}$", ErrorMessage = "Zadejte platné rodné číslo ve formátu RRMMDD/XXXX nebo RRMMDDXXXX.")]
        [UniqueRodneCislo]
        [RodneCisloFormat(ErrorMessage = "Rodné číslo má nesprávný formát nebo datum.")]
        public string RodneCislo { get; set; }

        public ICollection<PojistkaPerson> PojistkaPersons { get; set; }
    }
}
