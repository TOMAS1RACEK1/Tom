﻿using System.ComponentModel.DataAnnotations;

namespace Insurance.Data
{
    public class Udalost
    {
        [Key]

        public int Id { get; set; }

       


        [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
        [MaxLength(30), Display(Name = "Název události")]
        [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Je ve špatném formátu.")]
        public string NazevUdalosti { get; set; }

        [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
        [MaxLength(200), Display(Name = "Popis události")]
        [RegularExpression(@"^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ][a-zA-Zá-žÁ-Ž\s\-]*$", ErrorMessage = "Je ve špatném formátu.")]
        public string PopisUdalosti { get; set; }

        [Required(ErrorMessage = "Toto pole je povinné.")] // Hvězdička a zpráva
        [Display(Name = "Odhad škody")]
        // U typu int je zaručeno, že vstup bude celé číslo.
        // RegularExpression pro int není potřeba a je dokonce chybný (regex pro textové řetězce).
        // MaxLength pro int také není relevantní pro délku řetězce.
        [Range(0, int.MaxValue, ErrorMessage = "Zadejte platné celé číslo.")] // Volitelné: Omezení rozsahu a vlastní zpráva
        public int OdhadSkody { get; set; }

        [Display(Name = "Pojistka")]
        public int PojistkaId { get; set; } // Cizí klíč pro Pojistku 

        public Pojistka Pojistka { get; set; } // Navigační vlastnost pro Pojistku 
        //public ICollection<Udalost> Udalosti { get; set; }


    }
}
