﻿namespace Insurance.Data
{
    public class PojistkaPerson
    {
        public int PojistkaId { get; set; }
        public Pojistka Pojistka { get; set; }

        public int PersonId { get; set; }
        public Person Person { get; set; }
    }
}
