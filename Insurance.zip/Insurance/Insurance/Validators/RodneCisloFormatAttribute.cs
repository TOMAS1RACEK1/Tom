﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text.RegularExpressions;
using Insurance.Validators;

namespace Insurance.Validators
{
    public class RodneCisloFormatAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return new ValidationResult("Rodné číslo je povinné.");

            string rc = value as string;

            if (string.IsNullOrWhiteSpace(rc))
                return new ValidationResult("Rodné číslo je povinné.");

            // Odstraníme lomítko
            rc = rc.Replace("/", "");

            // Musí mít 9 nebo 10 číslic
            if (!Regex.IsMatch(rc, @"^\d{9,10}$"))
                return new ValidationResult("Rodné číslo má nesprávný formát.");

            //// Ověření dělitelnosti 11 u 10místného čísla
            //if (rc.Length == 10 && long.TryParse(rc, out long cislo))
            //{
            //    if (cislo % 11 != 0)
            //        return new ValidationResult("Rodné číslo není dělitelné 11.");
            //}
            //if (rc.Length == 10 && long.TryParse(rc, out long cislo))
            //{
            //    if (cislo % 11 != 0)
            //        return new ValidationResult("Rodné číslo není dělitelné 11.");
            //}



            // Získání složek data
            int rok = int.Parse(rc.Substring(0, 2));
            int mesic = int.Parse(rc.Substring(2, 2));
            int den = int.Parse(rc.Substring(4, 2));

            // Korekce měsíce podle pohlaví nebo jiných variant
            if (mesic >= 51 && mesic <= 62) mesic -= 50;
            else if (mesic >= 21 && mesic <= 32) mesic -= 20;
            else if (mesic >= 71 && mesic <= 82) mesic -= 70;

            // Rok narození - heuristicky rozlišujeme 1900/2000
            int plnyRok = rok >= 0 && rok <= 53 ? 2000 + rok : 1900 + rok;

            // Ověření existence data
            try
            {
                DateTime datum = new DateTime(plnyRok, mesic, den);
            }
            catch
            {
                return new ValidationResult("Rodné číslo obsahuje neplatné datum narození.");
            }

            return ValidationResult.Success;
        }
    }
}
