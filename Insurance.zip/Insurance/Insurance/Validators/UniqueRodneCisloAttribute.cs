﻿using Insurance.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Insurance.Validators; 

namespace Insurance.Validators;
public class UniqueRodneCisloAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        var rodneCislo = value as string;
        if (string.IsNullOrEmpty(rodneCislo))
            return ValidationResult.Success;

        var db = validationContext.GetService<ApplicationDbContext>();
        var entityType = validationContext.ObjectInstance.GetType();
        var idProperty = entityType.GetProperty("Id");

        if (idProperty == null)
            return new ValidationResult("Nelze najít vlastnost Id.");

        var currentId = (int)idProperty.GetValue(validationContext.ObjectInstance);

        bool existsInPojistenci = db.Pojistenci
            .Any(p => p.RodneCislo == rodneCislo && p.Id != currentId);

        bool existsInPersons = db.Persons
            .Any(p => p.RodneCislo == rodneCislo && p.Id != currentId);

        if (existsInPojistenci || existsInPersons)
        {
            return new ValidationResult("Toto rodné číslo je již používáno.");
        }

        return ValidationResult.Success;
    }
}
