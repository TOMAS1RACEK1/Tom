using Insurance.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Areas.Editor.Pages;

public class PojistkaEditModel : PageModel
{
    [BindProperty(SupportsGet = true)]
    public int IdPojistky { get; set; }

    [BindProperty(SupportsGet = true)]
    public int IdPojistence { get; set; }

    [BindProperty]
    public Pojistka Data { get; set; }

    [BindProperty]
    public Pojistka Pojistka { get; set; }

    [BindProperty]
    

    public List<SelectListItem> MoznePojistky { get; set; }
    public List<SelectListItem> MoznostiPojisteni { get; set; }

   

    public List<Pojistenec> Pojistenci { get; set; }
    


    readonly ApplicationDbContext DB;

    public PojistkaEditModel(ApplicationDbContext db)
    {
        DB = db;
    }

    public async Task OnGetAsync()
    {

        MoznePojistky = new List<SelectListItem>
    {
        new SelectListItem { Value = "Cestovn�", Text = "Cestovn�" },
        new SelectListItem { Value = "�ivotn�", Text = "�ivotn�" },
        new SelectListItem { Value = "�razov�", Text = "�razov�" },
        new SelectListItem { Value = "Dom�cnost", Text = "Dom�cnost" },
        new SelectListItem { Value = "Odpov�dnost", Text = "Odpov�dnost" },
        new SelectListItem { Value = "Mazl��ek", Text = "Mazl��ek" },
        new SelectListItem { Value = "Vozidlo", Text = "Vozidlo" },
    };


        MoznostiPojisteni = new List<SelectListItem>
    {
        new SelectListItem { Value = "Dovolen�", Text = "Dovolen�" },
        new SelectListItem { Value = "Sklep", Text = "Sklep" },
        new SelectListItem { Value = "Sport", Text = "Sport" },
        new SelectListItem { Value = "Televize", Text = "Televize" },
        new SelectListItem { Value = "Odpov�dnost", Text = "Odpov�dnost" },
        new SelectListItem { Value = "Osel", Text = "Osel" },
        new SelectListItem { Value = "V�l", Text = "V�l" },
        new SelectListItem { Value = "Motorka", Text = "Motorka" },
        new SelectListItem { Value = "Osobn�", Text = "Osobn�" },
        new SelectListItem { Value = "N�kladn�", Text = "N�kladn�" },
    };

        

        if (IdPojistky == 0)
        {
            Data = new Pojistka();
             if (IdPojistence != null)
                    Data.PojistenecId = (int)IdPojistence;
        }
        else
            Data = await DB.Pojistky 
        .FirstOrDefaultAsync(p => p.Id == IdPojistky);


        Pojistenci = await DB.Pojistenci
            .AsNoTracking()
            .OrderBy(x => x.Prijmeni)
            .ThenBy(x => x.Jmeno)
            .ToListAsync();

        


    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (IdPojistky != Data.Id)
            return Page();

        if (IdPojistky == 0)
            await DB.Pojistky.AddAsync(Data);
        else
            DB.Pojistky.Update(Data);
        TempData["ToastMessage"] = "Pojistka byla upravena.";
        await DB.SaveChangesAsync();
        return RedirectToPage("/PojistkaAddPersons", new { area = "Editor", IdPojistky = Data.Id });

        
    }

  

    public async Task<IActionResult> OnPostVymazatAsync(int idPojistky)
    {
        var pojistka = await DB.Pojistky
            .Include(p => p.Udalosti)
            .Include(p => p.PojistkaPersons)
            .FirstOrDefaultAsync(p => p.Id == idPojistky);

        if (pojistka == null)
            return NotFound();

        // Manu�ln� odstran�me osoby p�i�azen� k pojistce
        if (pojistka.PojistkaPersons != null && pojistka.PojistkaPersons.Any())
            DB.PojistkaPersons.RemoveRange(pojistka.PojistkaPersons);

        // Ud�losti budou smaz�ny automaticky (Cascade)
        DB.Pojistky.Remove(pojistka);

        await DB.SaveChangesAsync();

        TempData["ToastMessage"] = "Pojistka byla odstran�na.";

        return RedirectToPage("/Pojistky");
    }


}

