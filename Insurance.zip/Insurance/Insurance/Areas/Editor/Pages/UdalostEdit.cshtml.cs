
using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Areas.Editor.Pages;

public class UdalostEditModel : PageModel
{
  [BindProperty(SupportsGet = true)]
    public int IdUdalosti { get; set; }



    [BindProperty(SupportsGet = true)]
    public int? IdPojistky { get; set; }




    [BindProperty]
public Udalost Data { get; set; }

    public List<Pojistka> Pojistky { get; set; }








    readonly ApplicationDbContext DB;

public UdalostEditModel(ApplicationDbContext db)
{
    DB = db;
}

    public async Task OnGetAsync()
    {
        if (IdUdalosti == 0)
        {
            Data = new Udalost();
            if (IdPojistky != null)
                Data.PojistkaId = (int)IdPojistky;
        }
        else
            Data = await DB.Udalosti.FindAsync(IdUdalosti);

        Pojistky = await DB.Pojistky
              .AsNoTracking()
              .OrderBy(x => x.DruhPojistky)
              .ThenBy(x => x.PredmetPojisteni)
              .ToListAsync();

    }


    


   
   

    public async Task OnPostAsync()
    {
        if (IdUdalosti != Data.Id)
            return;
        bool jeNovy = Data.Id == 0;
        if (IdUdalosti == 0)
            await DB.Udalosti.AddAsync(Data);
        else
            DB.Udalosti.Update(Data);
        TempData["ToastMessage"] = jeNovy ? "Ud�lost byla ulo�ena." : "Ud�lost byla upravena.";
        await DB.SaveChangesAsync();
        
        Response.Redirect($"/udalost/{Data.Id}");
    }


    

    public async Task OnPostVymazatAsync(string idUdalosti)
{
    if (IdUdalosti != Convert.ToInt32(idUdalosti))
        return;

    DB.Udalosti.Remove(await DB.Udalosti.FindAsync(IdUdalosti)); 

    await DB.SaveChangesAsync();

        TempData["ToastMessage"] = "Ud�lost byla odstran�na."; 

        Response.Redirect($"/udalosti");
}
} 


