using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Areas.Editor.Pages;

public class PojistenecEditModel : PageModel
{
    [BindProperty(SupportsGet = true)] 

    public int IdPojistence { get; set; }

    [BindProperty] 

    public Pojistenec Data { get; set; } 


    readonly ApplicationDbContext DB; 

    public PojistenecEditModel(ApplicationDbContext db)
    {
        DB = db;
    }

    public async Task OnGetAsync()
    {
        if (IdPojistence == 0)
            Data = new Pojistenec();
        else
            Data = await DB.Pojistenci.FindAsync(IdPojistence);
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (IdPojistence != Data.Id)
            return Page(); 


        if (!ModelState.IsValid) return Page();
        //  DUPLICITA (pro jistotu ru�n�, i kdy� je UniqueRodneCislo)
        bool dup = await DB.Pojistenci
            .AnyAsync(p => p.RodneCislo == Data.RodneCislo && p.Id != Data.Id);

        if (dup)
        {
            ModelState.AddModelError("Data.RodneCislo", "Toto rodn� ��slo je ji� pou��v�no.");
            return Page();
        }



        bool jeNovy = Data.Id == 0; 

        if (IdPojistence == 0)
        { 
            await DB.Pojistenci.AddAsync(Data);
        TempData["ToastMessage"] = "Poji�t�nec byl p�id�n."; 
        } 

        else
            DB.Pojistenci.Update(Data); 

        TempData["ToastMessage"] = jeNovy ? "Poji�t�nec byl ulo�en." : "Poji�t�nec byl upraven.";
        
        

        await DB.SaveChangesAsync();
        return RedirectToPage("/Pojistenci");
        
    }
    

    public async Task<IActionResult> OnPostVymazatAsync(int idPojistence)
    {
        var pojistenec = await DB.Pojistenci
            .Include(p => p.Pojistky)
                .ThenInclude(poj => poj.Udalosti)
            .Include(p => p.Pojistky)
                .ThenInclude(poj => poj.PojistkaPersons)
            .FirstOrDefaultAsync(p => p.Id == idPojistence);

        if (pojistenec == null)
            return NotFound();

        //  Nejprve odstra� osoby p�i�azen� k pojistk�m
        foreach (var pojistka in pojistenec.Pojistky)
        {
            if (pojistka.PojistkaPersons != null && pojistka.PojistkaPersons.Any())
            {
                DB.PojistkaPersons.RemoveRange(pojistka.PojistkaPersons);
            }
        }

        DB.Pojistenci.Remove(pojistenec);
        await DB.SaveChangesAsync();

        TempData["ToastMessage"] = "Poji�t�nec byl odstran�n.";
        

        return RedirectToPage("/Pojistenci"); // nebo "/Pojistenci" podle struktury
    }



}
