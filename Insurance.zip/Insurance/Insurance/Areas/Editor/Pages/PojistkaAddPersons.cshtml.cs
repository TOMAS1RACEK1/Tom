using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Areas.Editor.Pages;

[BindProperties(SupportsGet = true)]

public class PojistkaAddPersonsModel : PageModel
{
    readonly ApplicationDbContext DB;
    public PojistkaAddPersonsModel(ApplicationDbContext db)
    {
        DB = db;
    }

    public int IdPojistky { get; set; }
    public Pojistka Pojistka { get; set; }

    public async Task<IActionResult> OnGetAsync()
    {
        Pojistka = await DB.Pojistky.FindAsync(IdPojistky);
        return Pojistka == null ? NotFound() : Page();
    }
}
