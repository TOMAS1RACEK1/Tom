using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Areas.Editor.Pages
{
    public class PojistkaPersonsAddModel : PageModel
    {
        private readonly ApplicationDbContext DB;
        public PojistkaPersonsAddModel(ApplicationDbContext db) => DB = db;

        [BindProperty(SupportsGet = true)]
        public int IdPojistky { get; set; }

        [BindProperty]
        public List<int> SelectedPersonIds { get; set; } = new();

        public List<SelectListItem> PersonsOptions { get; set; }

        public async Task OnGetAsync()
        {
            PersonsOptions = await DB.Persons
                .Select(p => new SelectListItem
                {
                    Value = p.Id.ToString(),
                    Text = $"{p.FirstName} {p.LastName}"
                }).ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            foreach (var pid in SelectedPersonIds)
            {
                DB.PojistkaPersons.Add(new PojistkaPerson { PojistkaId = IdPojistky, PersonId = pid });
            }
            await DB.SaveChangesAsync();
            return RedirectToPage("/pojistky");
        }
    }
}

