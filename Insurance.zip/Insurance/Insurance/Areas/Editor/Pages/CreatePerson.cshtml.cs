using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Insurance.Areas.Editor.Pages.Pojistky
{
    public class CreatePersonModel : PageModel
    {
        private readonly ApplicationDbContext DB;

        public CreatePersonModel(ApplicationDbContext db)
        {
            DB = db;
        }

        [BindProperty(SupportsGet = true)]
        public int PojistkaId { get; set; }

        public List<Person> PrirazeneOsoby { get; set; } = new();


        [BindProperty]
        public Person Person { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

           

            if (DB.Persons.Any(p => p.RodneCislo == Person.RodneCislo && p.Id != Person.Id))
            {
               
                return Page();
            } 

            DB.Persons.Add(Person);
            await DB.SaveChangesAsync();

            DB.PojistkaPersons.Add(new PojistkaPerson
            {
                PersonId = Person.Id,
                PojistkaId = PojistkaId
            });

            await DB.SaveChangesAsync(); 
            return RedirectToPage("/PojistkaDetail", new { id = PojistkaId });

        }

        public async Task<IActionResult> OnPostVymazatPersonAsync(int id)
        {
            var person = await DB.Persons
                .Include(p => p.PojistkaPersons)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (person == null)
                return NotFound();

            // Nen� nutn� ru�n� mazat vazby, proto�e DeleteBehavior.Cascade to ud�l�
            DB.Persons.Remove(person);

            await DB.SaveChangesAsync();
            return RedirectToPage("PojistkaDetail", new { id });
        }


    }
}
