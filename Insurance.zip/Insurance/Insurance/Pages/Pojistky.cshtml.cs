using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Pages;

public class PojistkyModel : PageModel
{
    readonly ApplicationDbContext DB;

    public List<Pojistka> Data { get; set; }

    public PojistkyModel(ApplicationDbContext db)
    {
        DB = db;
    }
    public async Task OnGetAsync()
    {
        Data = await DB.Pojistky
            .AsNoTracking()
            .Include(x => x.Pojistenec)
            .Include(x => x.Udalosti) // Include naviga�n� vlastnost Udalosti pro zobrazen� ud�lost� spojen�ch s pojistkou

            .OrderBy(x => x.DruhPojistky)
            .ToListAsync();
    }
}
