using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Insurance.Data;

namespace Insurance.Pages.Pojistky;

public class PojistkaPrintModel : PageModel
{
    private readonly ApplicationDbContext DB;

    public PojistkaPrintModel(ApplicationDbContext db)
    {
        DB = db;
    }

    public Pojistka Data { get; set; }
    public List<Person> Persons { get; set; } = new();
    public List<Udalost> Udalosti { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id)
    {
        Data = await DB.Pojistky
            .Include(p => p.Pojistenec)
            .Include(p => p.PojistkaPersons).ThenInclude(pp => pp.Person)
            .Include(p => p.Udalosti)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (Data == null)
            return NotFound();

        Persons = Data.PojistkaPersons.Select(pp => pp.Person).ToList();
        Udalosti = Data.Udalosti.ToList();

        return Page();
    }
}
