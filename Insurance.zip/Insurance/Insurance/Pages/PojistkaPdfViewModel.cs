﻿using Insurance.Data;

namespace Insurance.Pages
{
    public class PojistkaPdfViewModel
    {
        public Pojistka Data { get; set; } = new();
        public List<Person> Persons { get; set; } = new();
        public List<Udalost> Udalosti { get; set; } = new();

       

    }
}
