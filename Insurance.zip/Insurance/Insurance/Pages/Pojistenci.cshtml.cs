using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Insurance.Pages;

public class PojistenciModel : PageModel 
{

   
        private readonly ApplicationDbContext DB;

        public PojistenciModel(ApplicationDbContext db)
        {
            DB = db;
        }

        public List<Pojistenec> Data { get; set; }

        public int TotalPages { get; private set; }

        public int CurrentPage { get; private set; }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; } = string.Empty;

        [BindProperty(SupportsGet = true)]
        public double PageSize { get; set; } = 5;

        public async Task<IActionResult> OnGetAsync(int? pageNumber)
        {
            var query = DB.Pojistenci.AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchTerm))
            {
                query = query.Where(p => p.Prijmeni.Contains(SearchTerm));
            }

            CurrentPage = pageNumber ?? 1;

            int totalRecords = await query.CountAsync();
            TotalPages = (int)Math.Ceiling(totalRecords / PageSize);

            Data = await query
                .OrderBy(x => x.Prijmeni)
                .Skip((int)((CurrentPage - 1) * PageSize))
                .Take((int)PageSize)
                .ToListAsync();

            return Page();
        }

    public async Task<IActionResult> OnPostVymazatNeaktivniAsync()
    {
        var osobyBezPojistky = await DB.Persons
            .Where(p => !DB.PojistkaPersons.Any(pp => pp.PersonId == p.Id))
            .ToListAsync();

        if (osobyBezPojistky.Any())
        {
            DB.Persons.RemoveRange(osobyBezPojistky);
            await DB.SaveChangesAsync();
        }

        TempData["Message"] = $"Bylo smaz�no {osobyBezPojistky.Count} neaktivn�ch osob.";
        return RedirectToPage(); // Aktualizuj str�nku
    }


}




