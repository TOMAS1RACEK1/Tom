using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Pages;

public class UdalostDetailModel : PageModel
{
    [BindProperty(SupportsGet = true)]
    public int Id { get; set; }

    

    public Udalost Data { get; set; }
    //public Udalost Udalost { get; set; }

    readonly ApplicationDbContext DB;

    public UdalostDetailModel(ApplicationDbContext db)
    {
        DB = db;
    }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        Data = await DB.Udalosti
            .AsNoTracking()
            .Include(x => x.Pojistka)
            
            .FirstOrDefaultAsync(x => x.Id == Id);

        if (Data == null)
            return NotFound();

        return Page();
    }
}


