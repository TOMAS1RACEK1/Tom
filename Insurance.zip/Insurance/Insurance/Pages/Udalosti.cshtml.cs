﻿using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Pages;

public class UdalostiModel : PageModel
{
    readonly ApplicationDbContext DB;

    public List<Udalost> Data { get; set; }

    public UdalostiModel(ApplicationDbContext db)
    {
        DB = db;
    }
    public async Task OnGetAsync()
    {
        Data = await DB.Udalosti
            .AsNoTracking()
            .Include(x => x.Pojistka)
            .OrderBy(x => x.NazevUdalosti)
            .ToListAsync();
    }
}
