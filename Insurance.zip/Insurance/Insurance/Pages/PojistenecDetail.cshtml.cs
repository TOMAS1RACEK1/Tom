using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Pages;

public class PojistenecDetailModel : PageModel
{
    [BindProperty(SupportsGet = true)] 

    public int Id { get; set; } 

    public Pojistenec Data { get; set; }

    readonly ApplicationDbContext DB;

   

    public PojistenecDetailModel(ApplicationDbContext db)
    {
        DB = db;
    }
    public async Task OnGetAsync()
    {
        Data = await DB.Pojistenci
            .AsNoTracking()
            .Include(x => x.Pojistky)
            
            
            .FirstOrDefaultAsync(x => x.Id == Id);
    }
}
