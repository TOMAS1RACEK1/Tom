
using Insurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Rotativa;
using Rotativa.AspNetCore;

namespace Insurance.Pages;

public class PojistkaDetailModel : PageModel
{
    [BindProperty(SupportsGet = true)]
    public int Id { get; set; }

    public Pojistka Data { get; set; }

    public List<Person> PrirazeneOsoby { get; set; } = new();
    public Pojistka Pojistka { get; set; }
    public List<Udalost> Udalosti { get; set; }

    readonly ApplicationDbContext DB;

    public PojistkaDetailModel(ApplicationDbContext db)
    {
        DB = db;
    }




    public IActionResult OnGetExportPdf(int id)
    {
        var pojistka = DB.Pojistky
            .Include(p => p.Pojistenec)
            .Include(p => p.PojistkaPersons).ThenInclude(pp => pp.Person)
            .Include(p => p.Udalosti)
            .FirstOrDefault(p => p.Id == id);

        if (pojistka == null)
            return NotFound();

        var model = new PojistkaPdfViewModel
        {
            Data = pojistka,
            Persons = pojistka.PojistkaPersons.Select(pp => pp.Person).ToList() ?? new List<Person>(),
            Udalosti = pojistka.Udalosti.ToList() ?? new List<Udalost>(),
        };

        return new ViewAsPdf("PojistkaDetailPdf", model)
        {
            FileName = $"Pojistka_{id}.pdf"
        };
    }








    public async Task<IActionResult> OnGetAsync(int id)  


    {

        PrirazeneOsoby = await DB.Persons
    .OrderBy(p => p.LastName)
    .ToListAsync();


        Data = await DB.Pojistky
            .AsNoTracking()
            .Include(x => x.Pojistenec) // Include naviga�n� vlastnost Pojistenec pro zobrazen� jm�na poji�t�nce
                                        .Include(x => x.Udalosti) // Include naviga�n� vlastnost Udalosti pro zobrazen� ud�lost� spojen�ch s pojistkou 
                                        .Include(p => p.PojistkaPersons) // pokud chce� osoby
            .ThenInclude(pp => pp.Person) // pot�ebn� pro v�c osob
            .FirstOrDefaultAsync(x => x.Id == Id);

        if (Data == null)
            return NotFound();

        return Page();
    }

    public async Task<IActionResult> OnPostOdebratOsobuAsync(int id, int personId)
    {
        var vazba = await DB.PojistkaPersons
            .FirstOrDefaultAsync(pp => pp.PojistkaId == id && pp.PersonId == personId);

        if (vazba != null)
        {
            DB.PojistkaPersons.Remove(vazba);
            await DB.SaveChangesAsync();
        }

        // Vyhled�me osoby, kter� u� nejsou p�i�azen� k ��dn� pojistce
        var osobyBezPojistky = await DB.Persons
            .Where(p => !DB.PojistkaPersons.Any(pp => pp.PersonId == p.Id))
            .ToListAsync();

        return RedirectToPage(new { id });
    }

}
