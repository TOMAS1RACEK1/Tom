using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Insurance.Data;
using Rotativa.AspNetCore;

//using Insurance.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Insurance.Pages;

namespace Insurance.Views.Shared;

public class PojistkaDetailPdfModel : PageModel
{
    private readonly ApplicationDbContext DB;

    public PojistkaPdfViewModel ModelData { get; set; } = new();

    public PojistkaDetailPdfModel(ApplicationDbContext db)
    {
        DB = db;
    }
    [BindProperty(SupportsGet = true)]

    public Pojistka Data { get; set; }
    public Pojistka Pojistka { get; set; }
    public Person Person { get; set; } 
    public Udalost Udalost { get; set; } 
    public Pojistenec Pojistenec { get; set; }
    public List<Person> Persons { get; set; }
    public List<Udalost> Udalosti { get; set; } 
    public List<Pojistenec> Pojistenci { get; set; }


    public IActionResult OnGetExportPdf(int id)
    {
        var pojistka = DB.Pojistky
            .Include(p => p.Pojistenec)
            .Include(p => p.PojistkaPersons).ThenInclude(pp => pp.Person)
            .Include(p => p.Udalosti)
            .FirstOrDefault(p => p.Id == id);

        if (pojistka == null)
            return NotFound();

        var model = new PojistkaPdfViewModel
        {
            Data = pojistka,
            Persons = pojistka.PojistkaPersons.Select(pp => pp.Person).ToList() ?? new List<Person>(),
            Udalosti = pojistka.Udalosti.ToList() ?? new List<Udalost>(),
        };

        return new ViewAsPdf("PojistkaDetailPdf", model)
        {
            FileName = $"Pojistka_{id}.pdf"
        };
    }


    public async Task<IActionResult> OnGetAsync(int id)
    {
        // Na�teme pojistku podle ID v�etn� ud�lost� a propojen�ch osob
        Data = await DB.Pojistky
            .Include(p => p.Udalosti) 
            .Include(p => p.Pojistenec) // Na�teme pojistn�ka 
            .Include(pp => pp.Person)
            .Include(p => p.PojistkaPersons)
            .ThenInclude(pp => pp.Person)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (Pojistka == null)
        {
            return NotFound();
        }

        // Z�sk�me ID v�ech osob p�i�azen�ch k pojistce
        Persons = await DB.PojistkaPersons
            .Where(pp => pp.PojistkaId == id)
            .Include(pp => pp.Person)
            .ThenInclude(p => p.PojistkaPersons)

            .Select(pp => pp.Person)
            .ToListAsync();

        Udalosti = Pojistka.Udalosti?.ToList() ?? new List<Udalost>();

        return Page();
    }
}
