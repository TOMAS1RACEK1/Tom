﻿using Insurance.Data;
using Microsoft.AspNetCore.Mvc;

namespace Insurance.Components;

public class PrehledUdalostiViewComponent : ViewComponent
{
    public IViewComponentResult Invoke(PrehledUdalostiData data)
    {
        return View(data);
    }
}

public class PrehledUdalostiData
{
    public ICollection<Udalost> Udalosti { get; set; }
    public bool ZobrazovatPojistku{ get; set; } = true;
}
