﻿using Insurance.Data;
using Microsoft.AspNetCore.Mvc;

namespace Insurance.Components;

public class PrehledPojistekViewComponent : ViewComponent
{
    public IViewComponentResult Invoke(PrehledPojistekData data)
    {
        return View(data);
    }
}

public class PrehledPojistekData
{
    public ICollection<Pojistka> Pojistky { get; set; }
    public bool ZobrazovatPojistence { get; set; } = true;
}

